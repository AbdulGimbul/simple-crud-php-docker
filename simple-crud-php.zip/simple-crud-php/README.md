# Simple Create, Read, Update, Delete (CRUD) di PHP & MySQL

##### - Sudah Termasuk Upload Foto

##### - Database sudah tersedia dengan nama file **database.sql**
